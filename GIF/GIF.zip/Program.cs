﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Accord.Video.FFMPEG;

namespace VideoToGifConverter
{
    public partial class MainForm : Form
    {
        private string sourceVideoPath = "";
        private string outputGifPath = "";
        private VideoFileReader videoReader = null;
        private List<Bitmap> frames = new List<Bitmap>();
        private int frameSkip = 2; // Берем каждый второй кадр по умолчанию
        private int gifWidth = 320; // Размер GIF по умолчанию
        private int gifHeight = 240;
        private int frameDelay = 10; // Задержка между кадрами в сотых долях секунды

        public MainForm()
        {
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            // Инициализация элементов управления
            this.Text = "Video to GIF Converter";
            this.Width = 600;
            this.Height = 500;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Кнопки и поля
            Button btnSelectVideo = new Button
            {
                Text = "Выбрать видео",
                Location = new Point(20, 20),
                Width = 150,
                Height = 30
            };
            btnSelectVideo.Click += BtnSelectVideo_Click;
            this.Controls.Add(btnSelectVideo);

            TextBox txtVideoPath = new TextBox
            {
                Name = "txtVideoPath",
                Location = new Point(190, 20),
                Width = 370,
                Height = 30,
                ReadOnly = true
            };
            this.Controls.Add(txtVideoPath);

            Label lblFrameSkip = new Label
            {
                Text = "Пропуск кадров:",
                Location = new Point(20, 70),
                Width = 120,
                Height = 20
            };
            this.Controls.Add(lblFrameSkip);

            NumericUpDown nudFrameSkip = new NumericUpDown
            {
                Name = "nudFrameSkip",
                Location = new Point(150, 70),
                Width = 60,
                Height = 20,
                Minimum = 1,
                Maximum = 10,
                Value = frameSkip
            };
            nudFrameSkip.ValueChanged += (sender, e) => frameSkip = (int)nudFrameSkip.Value;
            this.Controls.Add(nudFrameSkip);

            Label lblGifSize = new Label
            {
                Text = "Размер GIF:",
                Location = new Point(250, 70),
                Width = 80,
                Height = 20
            };
            this.Controls.Add(lblGifSize);

            NumericUpDown nudGifWidth = new NumericUpDown
            {
                Name = "nudGifWidth",
                Location = new Point(340, 70),
                Width = 60,
                Height = 20,
                Minimum = 80,
                Maximum = 1280,
                Value = gifWidth,
                Increment = 40
            };
            nudGifWidth.ValueChanged += (sender, e) => gifWidth = (int)nudGifWidth.Value;
            this.Controls.Add(nudGifWidth);

            Label lblX = new Label
            {
                Text = "x",
                Location = new Point(410, 70),
                Width = 15,
                Height = 20,
                TextAlign = ContentAlignment.MiddleCenter
            };
            this.Controls.Add(lblX);

            NumericUpDown nudGifHeight = new NumericUpDown
            {
                Name = "nudGifHeight",
                Location = new Point(430, 70),
                Width = 60,
                Height = 20,
                Minimum = 60,
                Maximum = 720,
                Value = gifHeight,
                Increment = 30
            };
            nudGifHeight.ValueChanged += (sender, e) => gifHeight = (int)nudGifHeight.Value;
            this.Controls.Add(nudGifHeight);

            Label lblFrameDelay = new Label
            {
                Text = "Задержка кадра (мс):",
                Location = new Point(20, 110),
                Width = 130,
                Height = 20
            };
            this.Controls.Add(lblFrameDelay);

            NumericUpDown nudFrameDelay = new NumericUpDown
            {
                Name = "nudFrameDelay",
                Location = new Point(150, 110),
                Width = 60,
                Height = 20,
                Minimum = 1,
                Maximum = 100,
                Value = frameDelay
            };
            nudFrameDelay.ValueChanged += (sender, e) => frameDelay = (int)nudFrameDelay.Value;
            this.Controls.Add(nudFrameDelay);

            Button btnConvert = new Button
            {
                Name = "btnConvert",
                Text = "Конвертировать в GIF",
                Location = new Point(20, 150),
                Width = 170,
                Height = 30,
                Enabled = false
            };
            btnConvert.Click += BtnConvert_Click;
            this.Controls.Add(btnConvert);

            PictureBox previewBox = new PictureBox
            {
                Name = "previewBox",
                Location = new Point(20, 200),
                Width = 540,
                Height = 240,
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom
            };
            this.Controls.Add(previewBox);

            ProgressBar progressBar = new ProgressBar
            {
                Name = "progressBar",
                Location = new Point(200, 150),
                Width = 360,
                Height = 30,
                Style = ProgressBarStyle.Continuous,
                Minimum = 0,
                Maximum = 100,
                Value = 0
            };
            this.Controls.Add(progressBar);
        }

        private void BtnSelectVideo_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Video files (*.mp4;*.avi;*.mkv)|*.mp4;*.avi;*.mkv|All files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    sourceVideoPath = openFileDialog.FileName;
                    ((TextBox)this.Controls["txtVideoPath"]).Text = sourceVideoPath;
                    ((Button)this.Controls["btnConvert"]).Enabled = true;

                    // Предварительный просмотр видео (первый кадр)
                    try
                    {
                        if (videoReader != null)
                        {
                            videoReader.Dispose();
                        }
                        videoReader = new VideoFileReader();
                        videoReader.Open(sourceVideoPath);
                        Bitmap previewFrame = videoReader.ReadVideoFrame();
                        ((PictureBox)this.Controls["previewBox"]).Image = ResizeImage(previewFrame, gifWidth, gifHeight);
                        previewFrame.Dispose();
                        videoReader.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при открытии видео: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void BtnConvert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(sourceVideoPath))
            {
                MessageBox.Show("Выберите видеофайл для конвертации.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "GIF Image|*.gif";
                saveFileDialog.Title = "Сохранить GIF как";
                saveFileDialog.DefaultExt = "gif";
                saveFileDialog.AddExtension = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    outputGifPath = saveFileDialog.FileName;

                    // Отключаем элементы управления на время конвертации
                    EnableControls(false);

                    try
                    {
                        await Task.Run(() => ConvertVideoToGif());
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при конвертации: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        // Включаем элементы управления
                        EnableControls(true);
                    }
                }
            }
        }

        private void EnableControls(bool enabled)
        {
            // Метод для включения/отключения элементов управления
            this.Invoke((MethodInvoker)delegate
            {
                foreach (Control control in this.Controls)
                {
                    if (control.Name != "progressBar")
                    {
                        control.Enabled = enabled;
                    }
                }
            });
        }

        private void UpdateProgress(int value, int maximum)
        {
            // Безопасное обновление прогресс-бара с проверкой диапазона
            this.Invoke((MethodInvoker)delegate
            {
                try
                {
                    ProgressBar progressBar = (ProgressBar)this.Controls["progressBar"];

                    // Устанавливаем максимум перед значением, чтобы избежать ошибки диапазона
                    if (maximum > progressBar.Maximum)
                    {
                        progressBar.Maximum = maximum;
                    }

                    // Проверяем, что значение не выходит за допустимые границы
                    if (value < progressBar.Minimum)
                    {
                        progressBar.Value = progressBar.Minimum;
                    }
                    else if (value > progressBar.Maximum)
                    {
                        progressBar.Value = progressBar.Maximum;
                    }
                    else
                    {
                        progressBar.Value = value;
                    }
                }
                catch (Exception ex)
                {
                    // Логирование ошибки (в реальном приложении можно добавить более детальное логирование)
                    Console.WriteLine($"Ошибка при обновлении прогресса: {ex.Message}");
                }
            });
        }

        private void ConvertVideoToGif()
        {
            try
            {
                frames.Clear();

                if (videoReader != null)
                {
                    videoReader.Dispose();
                }

                videoReader = new VideoFileReader();
                videoReader.Open(sourceVideoPath);

                int frameCount = (int)videoReader.FrameCount;
                int processedFrames = 0;
                int frameIndex = 0;

                // Количество кадров с учетом пропусков
                int totalFramesToProcess = frameCount / frameSkip;
                if (totalFramesToProcess <= 0) totalFramesToProcess = 1; // Защита от деления на ноль

                this.Invoke((MethodInvoker)delegate
                {
                    // Показать сообщение о начале обработки и сбросить прогресс
                    ProgressBar progressBar = (ProgressBar)this.Controls["progressBar"];
                    progressBar.Value = 0;
                    // Безопасно установить максимум
                    if (totalFramesToProcess > 0)
                    {
                        progressBar.Maximum = totalFramesToProcess;
                    }
                    else
                    {
                        progressBar.Maximum = 100;
                    }
                });

                // Чтение и обработка кадров видео
                while (frameIndex < frameCount)
                {
                    Bitmap frame = videoReader.ReadVideoFrame();

                    if (frameIndex % frameSkip == 0)
                    {
                        // Изменяем размер кадра для GIF
                        Bitmap resizedFrame = ResizeImage(frame, gifWidth, gifHeight);
                        frames.Add(resizedFrame);

                        processedFrames++;
                        // Ограничиваем значение прогресса максимальным значением
                        int progressValue = Math.Min(processedFrames, totalFramesToProcess);
                        UpdateProgress(progressValue, totalFramesToProcess);
                    }

                    frame.Dispose();
                    frameIndex++;
                }

                videoReader.Close();

                // Сбрасываем прогресс-бар для следующей операции
                this.Invoke((MethodInvoker)delegate
                {
                    ProgressBar progressBar = (ProgressBar)this.Controls["progressBar"];
                    progressBar.Value = 0;
                    progressBar.Maximum = 100;
                });

                // Создание GIF-анимации из собранных кадров
                CreateGif(frames, outputGifPath, frameDelay);

                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show("GIF успешно создан!", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Отображаем созданный GIF в предпросмотре
                    try
                    {
                        Image gifImage = Image.FromFile(outputGifPath);
                        ((PictureBox)this.Controls["previewBox"]).Image = gifImage;
                    }
                    catch
                    {
                        // Если не удается загрузить GIF, просто показываем первый кадр
                        if (frames.Count > 0)
                        {
                            ((PictureBox)this.Controls["previewBox"]).Image = new Bitmap(frames[0]);
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show($"Ошибка при обработке видео: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                });
            }
            finally
            {
                if (videoReader != null)
                {
                    videoReader.Dispose();
                    videoReader = null;
                }
            }
        }

        private Bitmap ResizeImage(Bitmap image, int width, int height)
        {
            // Создаем новый Bitmap с 32-битным форматом пикселей (не индексированным)
            Bitmap destImage = new Bitmap(width, height, PixelFormat.Format32bppArgb);

            using (Graphics graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

                using (ImageAttributes wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(System.Drawing.Drawing2D.WrapMode.TileFlipXY);
                    graphics.DrawImage(image, new Rectangle(0, 0, width, height),
                        0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }

        // Метод для создания GIF-анимации - реализация собственного алгоритма
        private void CreateGif(List<Bitmap> images, string outputPath, int delay)
        {
            if (images.Count == 0)
                return;

            // Преобразуем задержку из сотых долей секунды в миллисекунды
            int delayMs = delay * 10;

            try
            {
                // Используем первый кадр для определения параметров
                using (Bitmap firstFrame = new Bitmap(images[0]))
                {
                    // Создаем временный файл для первого кадра
                    string tempFirstFrame = Path.GetTempFileName() + ".gif";
                    firstFrame.Save(tempFirstFrame, ImageFormat.Gif);

                    // Создаем новый GIF с нужными параметрами
                    using (Image gifImage = Image.FromFile(tempFirstFrame))
                    {
                        // Получаем соответствующую размерность
                        FrameDimension dimension = new FrameDimension(gifImage.FrameDimensionsList[0]);

                        // Настраиваем PropertyItem для задержки кадров
                        PropertyItem propItem = gifImage.GetPropertyItem(0x5100); // PropertyTagFrameDelay

                        // Создаем массив задержек для каждого кадра
                        byte[] delays = new byte[images.Count * 4];
                        for (int i = 0; i < images.Count; i++)
                        {
                            // Записываем задержку для каждого кадра в сотых долях секунды
                            BitConverter.GetBytes((short)delay).CopyTo(delays, i * 4);
                        }
                        propItem.Value = delays;

                        // Сохраняем GIF с нужными параметрами
                        using (Bitmap finalGif = new Bitmap(images[0].Width, images[0].Height))
                        {
                            using (Graphics g = Graphics.FromImage(finalGif))
                            {
                                g.Clear(Color.White); // Очищаем фон
                            }

                            // Настраиваем свойства кадра
                            finalGif.SetPropertyItem(propItem);

                            // Сохраняем как многокадровый GIF
                            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                ImageCodecInfo encoder = GetEncoder(ImageFormat.Gif);
                                EncoderParameters encoderParams = new EncoderParameters(1);
                                encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.MultiFrame);

                                finalGif.Save(fs, encoder, encoderParams);

                                // Добавляем остальные кадры
                                encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.FrameDimensionTime);

                                for (int frameIndex = 0; frameIndex < images.Count; frameIndex++)
                                {
                                    using (Bitmap frame = images[frameIndex])
                                    {
                                        finalGif.SaveAdd(frame, encoderParams);
                                    }

                                    // Обновляем прогресс
                                    int progressValue = (frameIndex + 1) * 100 / images.Count;
                                    UpdateProgress(Math.Min(progressValue, 100), 100);
                                }

                                // Закрываем многокадровое сохранение
                                encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.SaveFlag, (long)EncoderValue.Flush);
                                finalGif.SaveAdd(encoderParams);
                            }
                        }
                    }

                    // Удаляем временный файл
                    try { File.Delete(tempFirstFrame); } catch { }
                }
            }
            catch (Exception ex)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show($"Ошибка при создании GIF: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                });
            }
        }

        // Вспомогательный метод для получения кодека изображения
        private ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }

        // Метод для создания оптимальной палитры цветов
        private ColorPalette CreateOptimalPalette(Bitmap image, int colorCount)
        {
            // Для простоты используем популярные цвета
            // Реальная реализация должна использовать алгоритмы квантизации цветов (например, Median Cut)
            // Создаем временную индексированную картинку, чтобы получить палитру
            using (Bitmap temp = new Bitmap(image.Width, image.Height, PixelFormat.Format32bppArgb))
            {
                // Копируем изображение, что заставит систему создать палитру
                using (Graphics g = Graphics.FromImage(temp))
                {
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                }

                return temp.Palette;
            }
        }

        // Метод для конвертации битмапа в массив индексов палитры
        private byte[] ConvertToPaletteIndices(Bitmap image, ColorPalette palette)
        {
            int width = image.Width;
            int height = image.Height;
            byte[] result = new byte[width * height];

            // Блокируем биты для быстрого доступа
            BitmapData bmpData = image.LockBits(
                new Rectangle(0, 0, width, height),
                ImageLockMode.ReadOnly,
                PixelFormat.Format32bppArgb);

            try
            {
                int stride = bmpData.Stride;
                IntPtr scan0 = bmpData.Scan0;

                unsafe
                {
                    byte* p = (byte*)(void*)scan0;

                    for (int y = 0; y < height; y++)
                    {
                        for (int x = 0; x < width; x++)
                        {
                            int idx = y * stride + x * 4;

                            // Читаем цвет пикселя (BGRA формат)
                            byte b = p[idx];
                            byte g = p[idx + 1];
                            byte r = p[idx + 2];
                            // byte a = p[idx + 3]; // Прозрачность не используем в этой реализации

                            // Находим ближайший цвет в палитре
                            int paletteIndex = FindClosestPaletteIndex(palette, Color.FromArgb(r, g, b));

                            // Записываем индекс в результат
                            result[y * width + x] = (byte)paletteIndex;
                        }
                    }
                }
            }
            finally
            {
                image.UnlockBits(bmpData);
            }

            return result;
        }

        // Метод для нахождения ближайшего цвета в палитре
        private int FindClosestPaletteIndex(ColorPalette palette, Color targetColor)
        {
            int closestIndex = 0;
            int closestDistance = int.MaxValue;

            for (int i = 0; i < palette.Entries.Length; i++)
            {
                Color paletteColor = palette.Entries[i];

                // Вычисляем "расстояние" между цветами
                int dr = targetColor.R - paletteColor.R;
                int dg = targetColor.G - paletteColor.G;
                int db = targetColor.B - paletteColor.B;

                int distance = dr * dr + dg * dg + db * db;

                if (distance < closestDistance)
                {
                    closestDistance = distance;
                    closestIndex = i;
                }
            }

            return closestIndex;
        }

        // Метод для записи данных изображения с LZW сжатием
        private void WriteImageData(FileStream fs, byte[] indexedData, int width, int height)
        {
            // Минимальный размер кода
            byte minCodeSize = 8; // 8 бит для 256 цветов
            fs.WriteByte(minCodeSize);

            // В реальной реализации здесь должно быть полное LZW сжатие
            // Для простоты демонстрации используем базовое сжатие

            // Подготовим данные для записи
            using (MemoryStream ms = new MemoryStream())
            {
                // Простая реализация 1:1 (без реального сжатия)
                // В реальном приложении здесь должен быть алгоритм LZW сжатия

                int index = 0;
                while (index < indexedData.Length)
                {
                    int blockSize = Math.Min(255, indexedData.Length - index);
                    ms.WriteByte((byte)blockSize);

                    for (int i = 0; i < blockSize; i++)
                    {
                        ms.WriteByte(indexedData[index + i]);
                    }

                    index += blockSize;
                }

                // Окончание блока данных
                ms.WriteByte(0);

                // Запись всех данных в файл
                ms.Position = 0;
                byte[] buffer = new byte[ms.Length];
                ms.Read(buffer, 0, buffer.Length);
                fs.Write(buffer, 0, buffer.Length);
            }
        }

        // Вспомогательные методы для записи в поток
        private void WriteShort(Stream fs, short value)
        {
            fs.WriteByte((byte)(value & 0xFF));
            fs.WriteByte((byte)((value >> 8) & 0xFF));
        }

        private void WriteString(Stream fs, string str)
        {
            foreach (char c in str)
            {
                fs.WriteByte((byte)c);
            }
        }

        // Освобождение ресурсов при закрытии формы
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (videoReader != null)
            {
                videoReader.Dispose();
            }

            foreach (Bitmap frame in frames)
            {
                frame.Dispose();
            }
            frames.Clear();
        }
    }

    // Вспомогательный класс для инициализации элементов формы
    public partial class MainForm
    {
        private void InitializeComponent()
        {
            // По умолчанию пустой метод, так как элементы создаются в InitializeControls
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "MainForm";
            this.ResumeLayout(false);
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}